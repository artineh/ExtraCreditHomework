public class ClassOne {
    public int one;
    public int two = 1;
    public int changeOne(int illuminat){
        this.one=illuminat;
        return this.one;
    }
    public void changeTwo(int two){
        this.two=two;
    }
    public  int  sum(int a,int b){
        return a+b;
    }
    public ClassOne(){
        this.one=5;
        this.two=10;
    }

}

