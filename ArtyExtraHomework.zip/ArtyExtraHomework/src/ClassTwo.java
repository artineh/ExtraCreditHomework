public class ClassTwo {
    public  String privet = "barev";
    public  String poka = "hajox";
    public  String concatinate(String a, String b){
        a+=" ";
        for (int i=0;i<b.length();i++){
            a+=b.charAt(i);
        }
        return a;
    }
    public  String reverse(String a){
        String f = "";
        for(int i=a.length() - 1;i >= 0;i--){
            f += a.charAt(i);
        }
        return f;
    }
    public ClassTwo(){
        privet="Hello";
        poka="Byee";
    }
}

