public class Test {
    //Recursive factorial
    public static int factorial(int a){
        if (a < 1) {
            System.out.println("Inputed number is smaller than 0, counting factorial is not defined for negative integers.");
            return 0;
        } else {
            if (a == 1) {
                return a;
            } else return a * factorial(a - 1);
        }
    }
    //Main function for running the code of three classes
    public static void main(String[] args) {
        //Checking the factorial function
        System.out.println(factorial(4));
        //Class 1 test with two functions
        ClassOne obj1 = new ClassOne();

        System.out.println(obj1.one);//Initial value of var one
        obj1.changeOne(4);//changes value of var one
        System.out.println(obj1.one);//changed value of var one

        System.out.println(obj1.two);//Initial value of var two
        obj1.changeTwo(15);//changes value of var two
        System.out.println(obj1.two);//changed value of var two

        //Class 2 test with two functions
        ClassTwo obj2 = new ClassTwo();
        //as function concatinate returns an string, we can print it by System.out.println
        System.out.println(obj2.concatinate("alo", "ova?"));
        //and then we call the same function with same arguments and make that
        //the argument of the function called reverse.
        //and then we print that as it returns us String too
        System.out.println(obj2.reverse(obj2.concatinate("alo", "ova?")));
        //Class 3 test
        ClassThree newThree = new ClassThree();
        //func 1 test
        System.out.println(newThree.func1());
        //func2 Test
        newThree.func2(obj1,obj2);

    }
}
