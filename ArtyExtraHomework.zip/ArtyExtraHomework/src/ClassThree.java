public class ClassThree{
    public ClassOne one = new ClassOne();
    public ClassTwo two = new ClassTwo();
    public  String func1(){
        return (one.one + one.two) + two.privet;
    }
    public  int func2(ClassOne one,ClassTwo two){
        int temp =0;
        for (int i=0;i<two.privet.length();++i){
            temp+=1;
        }
        System.out.println((one.one * temp)/one.two);
        return (one.one * temp)/one.two;
    }
    public ClassThree(){
        ClassOne newOne = new ClassOne();
        one = newOne;
        ClassTwo newTwo = new ClassTwo();
        two = newTwo;
    }
}
